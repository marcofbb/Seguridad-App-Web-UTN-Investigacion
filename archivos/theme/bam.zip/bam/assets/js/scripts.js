/* Tabs Widget */
jQuery(document).ready( function() {
	if ( jQuery.isFunction(jQuery.fn.tabs) ) {
		jQuery( ".bm-tabs-wdt" ).tabs();
	}
});