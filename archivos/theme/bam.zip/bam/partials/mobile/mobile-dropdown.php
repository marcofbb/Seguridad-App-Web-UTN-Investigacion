<div class="mobile-dropdown">
    <nav class="mobile-navigation">
        <?php
            wp_nav_menu( array(
                'theme_location' => 'menu-1',
                'menu_id'        => 'primary-menu',
            ) );
        ?>
    </nav>
</div>