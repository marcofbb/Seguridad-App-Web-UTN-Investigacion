<?php
/*
Plugin Name: Upload Media IMG
Description: Sistema para subir imagenes, comprueba mime type para mayor seguridad.
Version:     1.0.0
Author:      SEGPAPPWEB
*/

if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'admin_menu', 'plugin_upload_media_plugin_menu' );  
function plugin_upload_media_plugin_menu(){    
	$page_title = 'Upload Media';   
	$menu_title = 'Upload Media';   
	$capability = 'manage_options';   
	$menu_slug  = 'upload-media-plugin';   
	$function   = 'plugin_upload_media_plugin_page';   
	$icon_url   = 'dashicons-admin-media';   
	$position   = 4;    
	add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );
} 

function plugin_upload_media_plugin_page(){
	require(__DIR__ . '/template_upload.php');
}