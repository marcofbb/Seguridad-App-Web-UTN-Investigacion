<?php 
$url = plugin_dir_url(__FILE__);
?>
<style>
	.contenedor {
		background-color: white;
		padding: 10px;
	}
	#iframecss {
	    min-height: 300px;
	    height: auto;
	}
</style>
<h1>Upload Media</h1>
<div class="contenedor">
	<iframe id="iframecss" src="<?php echo $url; ?>/imagehosting.php" width="100%" scrolling="auto" frameborder="0">
      <p>Texto alternativo para navegadores que no aceptan iframes.</p>
    </iframe>
</div>