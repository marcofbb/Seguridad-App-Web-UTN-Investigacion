<?php
/*
Plugin Name: Thumbnail img
Description: Comprime sus imagenes (de ser posible) para reducir su tamano sin perder calidad.
Version:     1.0.0
Author:      SegAPPweb
*/

function thumbnail_img_content_filter ( $html ) {
    $url_plugin = plugin_dir_url(__FILE__).'/img.php?data=';
    $url_content = content_url();
	$url_content2 = './../..';
    $html = str_replace($url_content, $url_plugin.$url_content2, $html);
    return $html;
}
add_filter( 'post_thumbnail_html', 'thumbnail_img_content_filter', 99);