<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
if(!isset($_GET['data']) or empty($_GET['data'])) exit('error');
$data = $_GET['data'];


function comprimir($data,$type){
    // SIMULAR COMPRESION
    return file_get_contents($data);
}


$path = @parse_url($data, PHP_URL_PATH);
$tmp_file_extension = explode('.',$path);
$file_extension = end($tmp_file_extension);
if($file_extension == 'jpg'){
    header("content-type: image/jpg");
    echo comprimir($data,$file_extension);
} elseif($file_extension == 'png'){
    header("content-type: image/png");
    echo comprimir($data,$file_extension);
} else {
    header("content-type: image/".$file_extension);
    echo comprimir($data,$file_extension);
}