<?php
/*
Plugin Name: Restrict login to IP
Description: Restringir login a WPADMIN a una unica IP (Compatible con Cloudflare)
Version:     1.0.0
Author:      SEGAPPWEB
*/

if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'admin_menu', 'plugin_check_tube_online_marcofbb_menu' );  
function plugin_check_tube_online_marcofbb_menu(){    
	$page_title = 'Restrict Login';   
	$menu_title = 'Restrict Login';   
	$capability = 'manage_options';   
	$menu_slug  = 'restric-login-ip-page';   
	$function   = 'restric_login_ip_page';   
	$icon_url   = 'dashicons-tagcloud';   
	$position   = 4;    
	add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position ); 
	add_action( 'admin_init', 'restrict_login_ip_vars' );
} 

if( !function_exists("restrict_login_ip_vars") ) { 
	function restrict_login_ip_vars() {   
		register_setting( 'restric-login-ip-settings', 'restric_login_ip_ip' ); 
	} 
} 

function restric_login_ip_page(){
	require(__DIR__ . '/template_admin.php');
}

function get_my_ip_restrict_login(){
    $ip = $_SERVER["REMOTE_ADDR"];
    if(isset($_SERVER['HTTP_CF_CONNECTING_IP']) and !empty($_SERVER['HTTP_CF_CONNECTING_IP'])) $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
    return $ip;
}

add_filter( 'authenticate', 'restrict_login_ip_auth_signon', 8, 3 );
function restrict_login_ip_auth_signon( $user, $username, $password ) {
    if(empty($username) or empty($password)){
        return $user;
    }
    if ( $user instanceof WP_User ) {
        return $user;
    }
    if ( is_wp_error( $user ) ) {
        return $user;
    }
    $ip_login = get_my_ip_restrict_login();
    $ip_allowed = get_option( 'restric_login_ip_ip' );
    if(empty($ip_allowed)) return $user;
    if($ip_allowed == $ip_login) return $user;
    $user = new WP_Error( 'authentication_failed_ip_not_allowed', __( '<strong>ERROR</strong>: IP not allowed.' ) );
    remove_action('authenticate', 'wp_authenticate_username_password', 20);
    remove_action('authenticate', 'wp_authenticate_email_password', 20);
    remove_action('authenticate', 'wp_authenticate_spam_check', 20);
    return $user;
}