<style>
	.contenedor {
		background-color: white;
		padding: 10px;
	}
	.procesando {
		padding: 10px;
		margin: 10px;
		background-color: lightgreen;
		color: black;
		text-align: center;
	}
</style>
<h1>Restrict Login IP</h1>
<div class="contenedor">
	<div><h2>Settings</h2></div>
	<hr>
	<div>
		<form method="post" action="options.php">
			<?php settings_fields( 'restric-login-ip-settings' ); ?>     
			<?php do_settings_sections( 'restric-login-ip-settings' ); ?>     
			<table class="form-table">
				<tr valign="top">
					<th scope="row">Your IP:</th>       
					<td><input type="text" name="restric_login_ip_ip" value="<?php echo esc_attr(get_option( 'restric_login_ip_ip' )); ?>"/><br><small>In blank for disabled.</small></td>
				</tr>   
			</table>     
			<?php echo submit_button(); ?>   
		</form>
	</div>
</div>