<?php 

/*
Plugin Name: Simplificar wordpress admin
Description: Plugin para simplificar el WPADMIN desactivando algunas funciones
Version:     1.0.0
Author:      SEGappWEB
*/

add_action( 'admin_menu', 'my_remove_menus', 999 );

function my_remove_menus() {

	remove_menu_page( 'upload.php' );
	remove_menu_page( 'options-general.php' );
	remove_menu_page( 'tools.php' );
	remove_menu_page( 'themes.php' );

}

if( !defined('DISALLOW_FILE_MODS') ){
	define( 'DISALLOW_FILE_MODS', true );
}